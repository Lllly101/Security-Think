### >


#### Description:

Buffer overflow in the ScStoragePathFromUrl function in the WebDAV
service in Internet Information Services (IIS) 6.0 in Microsoft Windows
Server 2003 R2 allows remote attackers to execute arbitrary code via a
long header beginning with "If: <http://" in a PROPFIND request, as
exploited in the wild in July or August 2016.


#### Exploitdb:
41992

#### Type:
Buffer Errors

#### Cve:
CVE-2017-7269

#### Date:
2017-03-26

#### Affected Versions :


#### References :
- [https://nvd.nist.gov/vuln/detail/CVE-2017-7269](https://nvd.nist.gov/vuln/detail/CVE-2017-7269)
- [https://www.cvedetails.com/cve/CVE-2017-7269/](https://www.cvedetails.com/cve/CVE-2017-7269/)
- [http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-7269](http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-7269)
- [https://www.exploit-db.com/exploits/41738/](https://www.exploit-db.com/exploits/41738/)
- [https://www.exploit-db.com/exploits/41992/](https://www.exploit-db.com/exploits/41992/)
- [http://www.securityfocus.com/bid/97127](http://www.securityfocus.com/bid/97127)
- [http://www.securitytracker.com/id/1038168](http://www.securitytracker.com/id/1038168)


### PoC Script

  #### Arguments

    - **auth**
      Credentials To Use For HTTP Login [Format: username:password]


    - **reverse-ip**
      IP To Reverse Connect On


    - **help**
      Display The Help Menu


    - **proxy**
      Proxy Server To Use [Format: scheme://host:port]


    - **cookie**
      Cookie String To Use


    - **debug**
      Debug Mode


    - **url**
      The Target URL [Format: scheme://host]


    - **reverse-port**
      Port On Which Toonnect Back


    - **timeout**
      Max Timeout For The HTTP Requests


    - **user-agent**
      User-Agent To Send To Server


    - **verbose**
      Be More Verbose


  #### Arguments Resume

  ```

            --url [VALUE]		: The Target URL [Format: scheme://host]
            --user-agent [VALUE]		: User-Agent To Send To Server
            --cookie [VALUE]		: Cookie String To Use
            --proxy [VALUE]		: Proxy Server To Use [Format: scheme://host:port]
            --timeout [VALUE]		: Max Timeout For The HTTP Requests
            --auth [VALUE]		: Credentials To Use For HTTP Login [Format: username:password]
            --help        		: Display The Help Menu
            --verbose        		: Be More Verbose
            --debug        		: Debug Mode
            --reverse-ip [VALUE]		: IP To Reverse Connect On
            --reverse-port [VALUE]		: Port On Which Toonnect Back
    ```
